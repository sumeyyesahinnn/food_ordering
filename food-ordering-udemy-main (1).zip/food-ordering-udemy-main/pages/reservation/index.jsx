import React from "react";
import Reservation from "../../components/Reservation";

const Index = () => {
  return (
    <React.Fragment>
      <Reservation />
    </React.Fragment>
  );
};

export default Index;
